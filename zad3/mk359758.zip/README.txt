I. R requirements:
    1. xgboost library

II. Running:
    1. Go into directory with script 'run_mk359758.R'
    2. In command line write: Rscript run_mk359758.R path_to_training_set path_to_test_set path_to_output

III. Example:
    Rscript run_mk359758.R letter-recognition-train.csv letter-recognition-test-without-decisions.csv mk359758.txt